package com.emamaker.voxelengine.block;

public enum CellId {
	
	ID_AIR,
	ID_GRASS,
	ID_DIRT,
	ID_WOOD,
	ID_LEAVES,
	ID_STONE

//	String name;
//	int textureArrayOff, textureAtlasX, textureAtlasY;

//	CellId(String name_, int textureArrayOff_, int textureAtlasX_, int textureAtlasY_) {
//	    this.name = name_;
//	    this.textureArrayOff = textureArrayOff_;
//	    this.textureAtlasX = textureAtlasX_;
//	    this.textureAtlasY = textureAtlasY_;
//	}
}

//public class CellId {
//    
//    public static byte ID_AIR = Byte.MAX_VALUE;
//    public static byte ID_GRASS = 0;
//    public static byte ID_DIRT = 1;
//    public static byte ID_WOOD = 2; 
//    public static byte ID_LEAVES = 3;
//    public static byte ID_STONE = 4;
//    
//}